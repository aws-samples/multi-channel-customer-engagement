import os
import boto3
from boto3.dynamodb.conditions import Key
import json

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_INTERACTION_VOICE'])

def lambda_handler(event, context):
    
    print(event)
    
    response = table.query(
    KeyConditionExpression=Key('customerId').eq(event["customerId"]), ScanIndexForward=True)
    
    return response