const AWS = require('aws-sdk');
var connect = new AWS.Connect();
// main entry to the flow

exports.handler = (event, context, callback) => {
    //define parameter values to use in initiating the outbound call

    var params = {
        ContactFlowId: "f0a9543e-73c4-44d9-8b35-7adcde79c796",
        DestinationPhoneNumber: "+18004633339",
        InstanceId: "4cc70bdb-cb91-4b87-8bce-a7a06769fa21",
        QueueId: "b14669cc-8359-4d6a-adc6-6d186b235b95",
        Attributes: {"Name": "MyAttribute"}
    };

    // method used to initiate the outbound call from Amazon Connect
    connect.startOutboundVoiceContact(params, function(err, data) {
        if (err) console.log(err, err.stack) ;
        else console.log(data);
    });

    callback(null, event);

};