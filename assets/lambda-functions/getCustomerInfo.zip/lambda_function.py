import os
import boto3
from boto3.dynamodb.conditions import Key
import json

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_CUSTOMER_DATA'])

def lambda_handler(event, context):
    
    response = table.query(
    KeyConditionExpression=Key('Id').eq(event["customerId"]), ScanIndexForward=True)
    
    return response