import os
import json
from decimal import *
from backend import backend

CUSTOMER_ID = "123456789"

b = backend()

def lambda_handler(event, context):
    b.locale = os.environ['LOCALE']
    print (json.dumps(event))
    return dispatch(event)

def dispatch(intent_request):

    intent_name = intent_request['currentIntent']['name']

    if intent_name == "welcomeMultichannel":
        response = get_welcome_response(intent_request)
    elif intent_name == "startSession":
        response = get_pin(intent_request)
    elif intent_name == "savingsAcctBalance" or intent_name == "savingsAccountBalance":
        response = get_savings_account(intent_request)
    elif intent_name == "creditCardBalance":
        response = get_credit_card(intent_request)
    elif intent_name == "creditCardPay":
        response = pay_credit_card(intent_request)
    elif intent_name == "creditAdvance":
        response = make_credit_advance(intent_request)
    elif intent_name == "officeSchedule":
        response = get_offices(intent_request)
    elif intent_name == "callRequest":
        response = request_call(intent_request)
    else:
        raise Exception('Intent with name ' + intent_name + ' not supported')
        
    print(response["dialogAction"]["message"]["content"])    
        
    b.logInteraction(CUSTOMER_ID, intent_name, response["dialogAction"]["message"]["content"])    
    return response    


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response

def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }
    
def get_welcome_response(intent_request):
    return close(intent_request['sessionAttributes'],
             'Fulfilled',
             {'contentType': 'PlainText',
              'content': b.welcomeMessage(CUSTOMER_ID)})
              
def get_pin(intent_request):
    speech_output =  b.getPin(CUSTOMER_ID)

    return close(intent_request['sessionAttributes'],
             'Fulfilled',
             {'contentType': 'PlainText',
              'content': speech_output})              
              
def get_savings_account(intent_request):
    pin = intent_request["currentIntent"]["slots"]["pin"]
    
    speech_output = b.getSavingsAccount(CUSTOMER_ID, pin)

    return close(intent_request['sessionAttributes'],
             'Fulfilled',
             {'contentType': 'PlainText',
              'content': speech_output})            

def get_credit_card(intent_request):
    pin = intent_request["currentIntent"]["slots"]["pin"]

    speech_output = b.getCreditCard(CUSTOMER_ID, pin)

    return close(intent_request['sessionAttributes'],
             'Fulfilled',
             {'contentType': 'PlainText',
              'content': speech_output})
              
def pay_credit_card(intent_request):
    amount = Decimal(intent_request["currentIntent"]["slots"]["payment"])
    pin = intent_request["currentIntent"]["slots"]["pin"]

    speech_output = b.payCreditCard(CUSTOMER_ID, pin, amount)

    return close(intent_request['sessionAttributes'],
             'Fulfilled',
             {'contentType': 'PlainText',
              'content': speech_output})              
        
def make_credit_advance(intent_request):
    requestedAmount = Decimal(intent_request["currentIntent"]["slots"]["cashAdvance"])
    pin = intent_request["currentIntent"]["slots"]["pin"]

    speech_output = b.makeCreditAdvance(CUSTOMER_ID, pin, requestedAmount)
    
    return close(intent_request['sessionAttributes'],
         'Fulfilled',
         {'contentType': 'PlainText',
          'content': speech_output})
          
def get_offices(intent_request):
    office_name = intent_request["currentIntent"]["slots"]["location"]
    
    speech_output = b.getOfficeSchedule(office_name)

    return close(intent_request['sessionAttributes'],
         'Fulfilled',
         {'contentType': 'PlainText',
          'content': speech_output})
          
def request_call(intent_request):   
    speech_output = b.requestCall(CUSTOMER_ID)

    return close(intent_request['sessionAttributes'],
         'Fulfilled',
         {'contentType': 'PlainText',
          'content': speech_output})
