import json
from decimal import *
from backend import backend

CUSTOMER_ID = "123456789"

b = backend()

def lambda_handler(event, context):
    print(event)
    b.locale = event["request"]["locale"]
    if event["session"]["new"]:
        on_session_started(
            {"requestId": event["request"]["requestId"]}, event["session"])

    if event["request"]["type"] == "LaunchRequest":
        return on_launch(event["request"], event["session"])
    elif event["request"]["type"] == "IntentRequest":
        return on_intent(event["request"], event["session"])
    elif event["request"]["type"] == "SessionEndedRequest":
        return on_session_ended(event["request"], event["session"])

def on_session_started(session_started_request, session):
    print ("Starting new session.")

def on_launch(launch_request, session):
    return get_welcome_response()

def on_intent(intent_request, session):

    intent = intent_request["intent"]
    intent_name = intent_request["intent"]["name"]

    if intent_name == "startSession":
        return get_pin(intent)
    if intent_name == "savingsAccountBalance":
        return get_savings_account(intent)
    if intent_name == "creditCardBalance":
        return get_credit_card(intent)
    if intent_name == "creditCardPay":
        return pay_credit_card(intent)   
    if intent_name == "creditAdvance":
        return make_credit_advance(intent)
    if intent_name == "officeSchedule":
        return get_offices(intent)
    if intent_name == "callRequest":
        return request_call(intent)    
    elif intent_name == "AMAZON.HelpIntent":
        return get_help_response(intent)  
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    else:
        raise ValueError("Invalid intent")

def on_session_ended(session_ended_request, session):
    print ("Ending session.")

def handle_session_end_request():
    card_title = b.skill_name + " - End"
    speech_output = b.getLocalizedMessage("STOP")
    should_end_session = True
    return build_response({},  build_speechlet_response("sessionEnd", card_title, speech_output, None, should_end_session))

def get_welcome_response():
    session_attributes = {}
    card_title = b.skill_name + " - Welcome"
    speech_output = b.welcomeMessage(CUSTOMER_ID)
    reprompt_text = ""
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response("sessionStart",
        card_title, speech_output, reprompt_text, should_end_session))

def get_help_response():
    session_attributes = {}
    card_title = b.skill_name + " - Help"
    speech_output = b.getLocalizedMessage("HELP")
    reprompt_text = b.getLocalizedMessage("HELP")
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response("help",
        card_title, speech_output, reprompt_text, should_end_session))        

def get_pin(intent):
    session_attributes = {}
    card_title = b.skill_name + " - Help"
    reprompt_text = ""
    should_end_session = False
   
    speech_output =  b.getPin(CUSTOMER_ID)

    return build_response(session_attributes, build_speechlet_response(intent["name"],
        card_title, speech_output, reprompt_text, should_end_session))

def get_savings_account(intent):
    session_attributes = {}
    card_title = b.skill_name + " - Savings Account"
    reprompt_text = ""
    should_end_session = False

    pin = intent["slots"]["pin"]["value"]
    
    speech_output = b.getSavingsAccount(CUSTOMER_ID, pin)

    return build_response(session_attributes, build_speechlet_response(intent["name"],
            card_title, speech_output, reprompt_text, should_end_session))    
          
def get_credit_card(intent):
    session_attributes = {}
    card_title = b.skill_name + " - Savings Account"
    reprompt_text = ""
    should_end_session = False
    
    pin = intent["slots"]["pin"]["value"]

    speech_output = b.getCreditCard(CUSTOMER_ID, pin)

    return build_response(session_attributes, build_speechlet_response(intent["name"],
            card_title, speech_output, reprompt_text, should_end_session))                          

def pay_credit_card(intent):
    session_attributes = {}
    card_title = b.skill_name + " - Credit Advance"
    reprompt_text = ""
    should_end_session = False
    
    amount = Decimal(intent["slots"]["payment"]["value"])
    pin = intent["slots"]["pin"]["value"]

    speech_output = b.payCreditCard(CUSTOMER_ID, pin, amount)

    return build_response(session_attributes, build_speechlet_response(intent["name"],
        card_title, speech_output, reprompt_text, should_end_session))  

def make_credit_advance(intent):
    session_attributes = {}
    card_title = b.skill_name + " - Credit Advance"
    reprompt_text = ""
    should_end_session = False
    
    requestedAmount = Decimal(intent["slots"]["cashAdvance"]["value"])
    pin = intent["slots"]["pin"]["value"]

    speech_output = b.makeCreditAdvance(CUSTOMER_ID, pin, requestedAmount)

    return build_response(session_attributes, build_speechlet_response(intent["name"],
        card_title, speech_output, reprompt_text, should_end_session))
        
def get_offices(intent):
    session_attributes = {}
    card_title = b.skill_name + " - Offices"
    reprompt_text = ""
    should_end_session = False
    
    office_name = intent["slots"]["location"]["value"]
    
    speech_output = b.getOfficeSchedule(office_name)

    return build_response(session_attributes, build_speechlet_response(intent["name"], 
            card_title, speech_output, reprompt_text, should_end_session))

def request_call(intent):   
    session_attributes = {}
    card_title = b.skill_name + " - Request Call"
    reprompt_text = ""
    should_end_session = False
    
    speech_output = b.requestCall(CUSTOMER_ID)

    return build_response(session_attributes, build_speechlet_response(intent["name"],
            card_title, speech_output, reprompt_text, should_end_session))    

def build_speechlet_response(intent_name, title, output, reprompt_text, should_end_session):
    b.logInteraction(CUSTOMER_ID, intent_name, output)
    return {
        "outputSpeech": {
            "type": "SSML",
            "ssml": "<speak><prosody rate='medium'>" + output + "</prosody></speak>"
        },
        "card": {
            "type": "Simple",
            "title": title,
            "content": output
        },
        "reprompt": {
            "outputSpeech": {
                "type": "SSML",
                "ssml": "<speak><prosody rate='medium'>" + output + "</prosody></speak>"
            }
        },
        "shouldEndSession": should_end_session
    }

def build_response(session_attributes, speechlet_response):
    response =  {
        "version": "1.0",
        "sessionAttributes": session_attributes,
        "response": speechlet_response
    }
    return response