import boto3
from urllib.request import urlopen
import os
import json
s3 = boto3.client('s3')
import uuid
from datetime import datetime
import base64
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ['TABLE_INTERACTION_APP'])

def lambda_handler(event, context):
    try:
        print(json.dumps(event))
        
        for record in event['Records']:
            payload=json.loads(base64.b64decode(record["kinesis"]["data"]))
            print("Decoded payload: " + str(payload))
            
            #save interaction to DynamoDB    
            interaction = {
                'customerId': payload["customerId"],
                'interactionId': uuid.uuid1().hex,
                'interactionDateTime': datetime.now().isoformat(),
                'interactionType': 'Web Page Navigation',
                'interactionData': payload
            }
        
            responseDynamo = table.put_item(
                Item = interaction
            )
            
        return {"Done": True}
    except Exception as e:
        raise e
