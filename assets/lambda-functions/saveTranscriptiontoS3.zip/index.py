import boto3
from urllib.request import urlopen
import json
s3 = boto3.client('s3')
import uuid
from datetime import datetime
import os

region= os.environ['AWS_REGION']
dynamodb = boto3.resource("dynamodb", region_name=region)
table_name = os.environ['CUSTOMER_TABLE_NAME']
table = dynamodb.Table(table_name)


def lambda_handler(event, context):
    try:
        print(event)
        transcript_name = event["jobName"]+".json"
        transcript_path = "/tmp/"+transcript_name
        transcripts_bucket = event["transcriptDestination"]
        link = event["TranscriptionJob"]["TranscriptionJob"]["Transcript"]["TranscriptFileUri"]
        f = urlopen(link)
        transcript_str = f.read()
        transcript_obj = json.loads(transcript_str)
        with open(transcript_path, 'w') as outfile:
            json.dump(transcript_obj, outfile)
         
        #save interaction to DynamoDB    
        interaction = {
            'customerId': '123456789',
            'interactionId': event["jobName"],
            'interactionDateTime': datetime.now().isoformat(),
            'interactionType': 'Call Transcript',
            'transcribeJobId': event["jobName"],
            'transcript': transcript_obj["results"]["transcripts"][0]["transcript"]
        }
    
        responseDynamo = table.put_item(
            Item = interaction
        )
            
        response = s3.upload_file(transcript_path, transcripts_bucket, "transcripts/"+transcript_name)
        return {"Done": True}
    except Exception as e:
        raise e
