console.log('Loading function');
const aws = require('aws-sdk');
const s3 = new aws.S3();
var cfnresponse = require('./cfn-response')
let region = process.env.AWS_REGION
const docClient = new aws.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    const bucketName = process.env.bucketName;
    const keyName = process.env.key;
    const params = { Bucket: bucketName, Key: keyName };
    const csv = require('csvtojson');

    if (event['RequestType'] == 'Create') {
        console.log('here1');


        const s3Stream = s3.getObject(params).createReadStream()

        var paramsPut = {
            Item: {
                "Id": '123456789',
                "FirstName": 'John',
                "LastName": 'Doe',
                "Pin": '1212',
                "Balance": 2000,
                "BalanceCredit": 1500,
                "CreditLimit": 3000,
                "PaymentDueDate": '03/20/2021',
                "Phone": process.env.Phone
            },
            TableName: process.env.tableNameCustomer
        }

        docClient.put(paramsPut, function(err, data) {
            if (err) console.log(err);
            else console.log(data);
            csv().fromStream(s3Stream)
                .on('done', (error) => {
                    console.log("All Good All Good")
                    cfnresponse.send(event, context, cfnresponse.SUCCESS, {});
                })
                .on('data', (row) => {
                    //read each row 
                    let jsonContent = JSON.parse(row);
                    console.log(JSON.stringify(jsonContent));

                    //push each row into DynamoDB
                    let paramsToPush = {
                        TableName: process.env.tableNameLocalization,
                        Item: {
                            "messageId": jsonContent.messageId,
                            "locale": jsonContent.locale,
                            "message": jsonContent.message
                        }
                    };
                    docClient.put(paramsToPush, function(err, data) {
                        if (err) {
                            console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
                        }
                        else {
                            console.log("Added item:", JSON.stringify(params.Item, null, 2));

                        }
                    });
                });

        });

    }
    if (event['RequestType'] == 'Delete') {
        //console.log('here'),
        //console.log(event),

        cfnresponse.send(event, context, cfnresponse.SUCCESS, {});
    }


};
