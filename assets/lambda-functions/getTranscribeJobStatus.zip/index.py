import boto3
import json
import datetime

client = boto3.client('transcribe')


def lambda_handler(event, context):
    print(event)
    
    try:
        jobName = event["TranscriptionJob"]["TranscriptionJobName"]
        print(jobName)

        response = client.get_transcription_job(
            TranscriptionJobName=jobName
        )
        
        print(str(response))
        
        encoder = DateTimeEncoder()
        result = encoder.encode(response)
        
        print(json.loads(result))
        return json.loads(result)
    except Exception as e:
        print(str(e))

class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
            return obj.isoformat()
        elif isinstance(obj, datetime.timedelta):
            return (datetime.datetime.min + obj).time().isoformat()

        return super(DateTimeEncoder, self).default(obj)