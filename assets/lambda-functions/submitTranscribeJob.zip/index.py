import boto3
import json
import datetime
client = boto3.client('transcribe')
import uuid

def lambda_handler(event, context):
    print(event)
    try:
        job_name = event["jobName"]+"-"+uuid.uuid4().hex #RANDOMNESS
        media_format = event["mediaFormat"]
        file_uri = event["fileUri"]
        language_code = event["languageCode"]

        response = client.start_transcription_job(
            TranscriptionJobName=job_name,
            LanguageCode=language_code,
            MediaFormat=media_format,
            Media={
                'MediaFileUri': file_uri
            }
        )
        
        print (response)
        encoder = DateTimeEncoder()
        print (json.loads(encoder.encode(response)))
        return json.loads(encoder.encode(response))

    except Exception as e:
        raise(e)
        
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
            return obj.isoformat()
        elif isinstance(obj, datetime.timedelta):
            return (datetime.datetime.min + obj).time().isoformat()

        return super(DateTimeEncoder, self).default(obj)        